<?php
/**************************************************
  Coppermine 1.5.x Plugin - template
**************************************************/

// Make sure that this file can't be accessed directly, but only from within the Coppermine user interfaceif (!defined('IN_COPPERMINE')) {
    die('Not in Coppermine...');
}

$name = $lang_plugins['template']['plugin_name'];
$description = $lang_plugins['template']['plugin_description'];
$author = 'Your name here';
$version = '1.1';
$plugin_cpg_version = array('min' => '1.6');
$install_info = $lang_plugins['template']['install_info'];
$extra_info = $lang_plugins['template']['extra_info'];
$extra_info .= '<br /><a href="index.php?file=template/admin" class="admin_menu">' . cpg_fetch_icon('config', 1) . sprintf($lang_plugins['template']['configure_x'], $lang_plugins['template']['plugin_name']) . '</a>';

?>
