<?php
/******************************************
 Coppermine 1.6.x Plugin - Hello, World
*******************************************/

$name='Hello, World (tutorial 2.2.1)';
$description='Plugin API Tutorial - 2.2.1 Simple Installation';
$author='Tutorial';
$version='2.2.1';

//EOF