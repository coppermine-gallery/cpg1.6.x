<?php
/**************************************************
  Coppermine Plugin - Hello, World
  *************************************************
  Copyright (c) 2008 <-InsertNameHere->
  *************************************************
  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 3 of the License, or
  (at your option) any later version.
***************************************************/

if (!defined('IN_COPPERMINE')) die('Not in Coppermine...');

// Add a filter for the gallery header
$thisplugin->add_filter('gallery_header','helloworld_header');

// Sample function to modify gallery header html
function helloworld_header($html) {
    $html = '<p style="color:red"><b>Hello, world.</b> (tutorial 2.1)</p>'
            .$html;
    return $html;
}
?>